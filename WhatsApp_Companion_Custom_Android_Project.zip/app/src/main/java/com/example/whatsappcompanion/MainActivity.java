package com.example.whatsappcompanion;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView web;
    private static final String URL = "https://web.whatsapp.com/";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        TextView bar = new TextView(this);
        bar.setText("  WhatsApp Companion");
        bar.setTextColor(Color.WHITE);
        bar.setTextSize(18);
        bar.setGravity(16);
        bar.setBackgroundColor(Color.rgb(7,94,84));
        bar.setPadding(12,0,12,0);
        root.addView(bar, new LinearLayout.LayoutParams(-1,56));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36");
        s.setSupportZoom(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl(URL);

        root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
