# WhatsApp Companion Custom

This is a small Android project intended to open WhatsApp Web in a dedicated app window.

Usage:
1. Build/install the APK.
2. Open the app.
3. If WhatsApp Web provides a QR login, scan it from the account owner's WhatsApp > Linked devices.
4. The account owner must authorize the linked session.

This project does not bypass WhatsApp authentication or access an account without authorization.

Build with Android Studio using Gradle/Android Gradle Plugin.
